package com.capgi.dao;

import java.util.List;

import com.capgi.bean.WalletAccount;

public interface WalletDao {

	WalletAccount createAccount(WalletAccount wallet);

	List<WalletAccount> getAccountDetails();

	WalletAccount getWalletById(Long accountNo);

	WalletAccount depositAmount(WalletAccount wallet);

	

}
