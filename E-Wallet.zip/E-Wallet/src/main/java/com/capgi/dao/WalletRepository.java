package com.capgi.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.capgi.bean.WalletAccount;

@Repository
public class WalletRepository implements WalletDao{

	@Autowired
	WalletRepositoryInterface repo;
	
	@Override
	public WalletAccount createAccount(WalletAccount wallet) {
		
		return repo.save(wallet);
	}

	@Override
	public List<WalletAccount> getAccountDetails() {
		
		return repo.findAll();
	}

	@Override
	public WalletAccount getWalletById(Long accountNo) {
		return repo.findById(accountNo).orElse(new WalletAccount());
	}

	@Override
	public WalletAccount depositAmount(WalletAccount wallet) {
		
	    return repo.save(wallet);
	}

}
